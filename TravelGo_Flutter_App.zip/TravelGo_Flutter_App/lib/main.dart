
import 'package:flutter/material.dart';

void main() {
  runApp(const TravelGoApp());
}

class TravelGoApp extends StatelessWidget {
  const TravelGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TravelGo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('TravelGo'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: const [
            RouteCard(
              from: 'Ahmedabad',
              to: 'Mumbai',
              type: 'Train',
              price: '₹850',
            ),
            RouteCard(
              from: 'Delhi',
              to: 'Jaipur',
              type: 'Bus',
              price: '₹499',
            ),
            RouteCard(
              from: 'Surat',
              to: 'Goa',
              type: 'Sleeper Bus',
              price: '₹1200',
            ),
          ],
        ),
      ),
    );
  }
}

class RouteCard extends StatelessWidget {
  final String from;
  final String to;
  final String type;
  final String price;

  const RouteCard({
    super.key,
    required this.from,
    required this.to,
    required this.type,
    required this.price,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$from → $to',
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(type),
              ],
            ),
            ElevatedButton(
              onPressed: () {},
              child: Text(price),
            ),
          ],
        ),
      ),
    );
  }
}
